import queue

def ls_adiacenta(fisier):
    global ls, n, m
    f = open(fisier, 'r')
    n, m = [int(x) for x in f.readline().split()]
    ls = [[] for i in range(n+1)]
    for linie in f:
        l = linie.split()
        ls[int(l[0])].append(int(l[1]))
        ls[int(l[1])].append(int(l[0]))
    f.close()

def BFS(s, t):
    global d_min, l_min
    coada = queue.Queue()
    coada.put(s)
    viz[s] = 1
    d[s] = 0
    while not coada.empty():
        i = coada.get()
        if i == t and d[i] <= d_min:
            lanturi = [[i]]
            lant = [i]
            x = i
            while s not in lant:
                if len(tata[x]) == 1:
                    for j in range(len(lanturi)):
                        lanturi[j].insert(0, tata[x][0])
                    lant.insert(0, tata[x][0])
                else:
                    for j in range(len(tata[x])-1):
                        lanturi.append([])
                        for k in range(len(lanturi[j])):
                            lanturi[len(lanturi)-1].append(lanturi[j][k])
                    j = 0
                    for el in range(len(tata[x])):
                        lanturi[j].insert(0, tata[x][el])
                        lant.insert(0, tata[x][el])
                        j += 1
                if x != s:
                    x = tata[x][0]
            if d[i]<d_min:
                d_min = d[i]
            l_min = lanturi
        for j in ls[i]:
            if viz[j] == 0:
                coada.put(j)
                viz[j] = 1
                tata[j].append(i)
                d[j] = d[i] + 1
            elif d[j]==d[i]+1:
                tata[j].append(i)


if __name__ == '__main__':
    ls_adiacenta("graf_ex5.txt")
    s = int(input(f"Introduceti varful sursa (valoare intre 1 si {len(ls)-1}) : "))
    t = int(input(f"Introduceti varful destinatie (valoare intre 1 si {len(ls)-1}) : "))
    l_min = []
    d_min = float('inf')
    viz = [0] * (n+1)
    tata = [[] for i in range(n+1)]
    d = [-1] * (n+1)
    BFS(s, t)
    if d_min == float('inf'):
        print(f"Nu se poate ajunge la nodul {t}\n")
    else:
        print(f"Distanta de la nodul {s} pana la nodul {t} este : {d_min}")
        if len(l_min) == 1:
            print(f"Lantul minim de la nodul {s} pana la nodul {t} este: {l_min[0]}")
        else:
            print(f"Lanturile minime de la nodul {s} pana la nodul {t} sunt: ")
            for x in l_min:
                print(x)
