def ls_adiacenta(fisier):
    f = open(fisier, 'r')
    vf, muchii = [int(x) for x in f.readline().rstrip().split()]
    ls = [[] for i in range(vf)]
    for aux in f:
        muchii -= 1
        aux = aux.rstrip().split()
        i = int(aux[0])
        j = int(aux[1])
        ls[i-1].append(j-1)
        ls[j-1].append(i-1)
        if muchii == 0:
            break
    f.close()
    return ls

def DFS(i):
    global ciclu_gasit
    if ciclu_gasit:
        return
    viz[i] = 1
    for j in ls[i]:
        if viz[j] == 0:
            tata[j] = i
            DFS(j)
        elif tata[i] != j:
            muchie_int = [i+1, j+1]
            while i!=j:
                ciclu.append(i+1)
                i = tata[i]
            ciclu.append(i+1)
            ciclu.append(muchie_int[0])
            ciclu_gasit = True
            return
        if ciclu_gasit:
            return


viz = []
tata = []
ls = []
ciclu = []
ciclu_gasit = False

if __name__ == "__main__":
    ls = ls_adiacenta("graf_c.txt")
    viz = [0]*len(ls)
    tata = [-1]*len(ls)
    for i in range(len(ls)):
        if ciclu_gasit:
            break
        if viz[i] == 0:
            DFS(i)
    if ciclu:
        for x in ciclu:
            print(x, end=" ")
    else:
        print("Nu este ciclu")
