import queue

def ls_adiacenta(fisier, tip):
    ls = []
    f = open(fisier, 'r')
    aux = f.readline().rstrip().split()
    muchii = int(aux[1])
    aux = int(aux[0])
    for x in range(0, aux):
        ls.append([])
    for aux in f:
        muchii -= 1
        aux = aux.rstrip().split()
        i = int(aux[0])
        j = int(aux[1])
        ls[i-1].append(j-1)
        if tip == "n":
            ls[j-1].append(i-1)
        if muchii == 0:
            break
    pct_control = []
    aux = f.readline().rstrip().split()
    for x in aux:
        pct_control.append(int(x))
    f.close()
    return ls, pct_control

def BFS(s, ls, pct_control):
    viz = []
    tata = []
    d = []
    for aux in ls:
        viz.append(0)
        tata.append(0)
        d.append(-1)
    coada = queue.Queue()
    coada.put(s)
    viz[s] = 1
    d[s] = 0
    while not coada.empty():
        i = coada.get()
        if (i+1 in pct_control):
            print("\n" + str(i+1) + " e cel mai apropiat punct de control")
            print(f"Distanta pana la punct este : {d[i]}")
            print("Drumul pana la punct este: ", end="")
            drum = []
            drum.append(i+1)
            x = tata[i]
            while s+1 not in drum:
                drum.insert(0, x+1)
                x = tata[x]
            for x in drum:
                print(x, end=" ")
            print()
            return drum
        for j in ls[i]:
            if viz[j] == 0:
                coada.put(j)
                viz[j] = 1
                tata[j] = i
                d[j] = d[i] + 1
    print("Nu se poate ajunge la un punct de control\n")
    return []

if __name__ == '__main__':
    tip = input("Introduceti tipul grafului [orientat(o) sau neorientat(n)] : ")
    if tip != "o" and tip != "n":
        print(tip, "nu este un tip corect")
        exit(0)
    ls, pct_control = ls_adiacenta("pct_control.in", tip)
    sursa = int(input(f"Introduceti varful sursa (valoare intre 1 si {len(ls)}) : "))
    drum = BFS(sursa-1, ls, pct_control)
    g = open("pct_control.out", "w")
    for x in drum:
        g.write(f"{x} ")
    g.close()
