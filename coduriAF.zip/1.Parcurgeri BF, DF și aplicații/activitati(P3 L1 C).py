def ls_adiacenta(fisier):
    global ls, n, m
    f = open(fisier, 'r')
    n, m = [int(x) for x in f.readline().split()]
    ls = [[] for i in range(n+1)]
    for linie in f:
        l = linie.split()
        ls[int(l[0])].append(int(l[1]))
    f.close()

def DFS(x):
    global ok, viz, tata, fin
    viz[x] = 1
    for y in ls[x]:
        if ok != 0:
            break
        if viz[y] == 0:
            #print(y, end=" ") #asta e pt parcurgere
            tata[y] = x
            DFS(y) ##pana aici parcurgere obisnuita
        elif fin[y] != 1:
                #y nu a fost finalizat este inca in explorare
                print("circuit elementar")
                #afisare lant de la x la y
                v = x
                while v != y:
                    print(v, end=" ")
                    v = tata[v]
                print(y, sep=" ")
                ok = 1
    fin[x] = 1 #finalizare explorare x


ls_adiacenta("activitati.txt")
viz = [0]*(n+1)
tata = [0]*(n+1)
fin = [0]*(n+1)
ok = 0
start = 1
DFS(start)
if ok == 0:
    print("REALIZABIL")
