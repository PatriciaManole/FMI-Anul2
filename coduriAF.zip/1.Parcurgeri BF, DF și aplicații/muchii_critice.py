def ls_adiacenta(fisier):
    f = open(fisier, 'r')
    vf, muchii = [int(x) for x in f.readline().rstrip().split()]
    ls = [[] for i in range(vf)]
    for aux in f:
        muchii -= 1
        aux = aux.rstrip().split()
        i = int(aux[0])
        j = int(aux[1])
        ls[i-1].append(j-1)
        ls[j-1].append(i-1)
        if muchii == 0:
            break
    f.close()
    return ls

def DFS(nivel, i):
    nivel += 1
    if viz[i] == 0:
        viz[i] = 1
        niv[i] = [nivel, nivel]
    for j in ls[i]:
        if viz[j] == 0:
            DFS(nivel, j)
            if niv[j][1] > niv[i][0]:
                m_c.append([i+1, j+1])
            niv[i][1] = min(niv[i][1], niv[j][1])
        elif niv[j][0] < niv[i][0] - 1:
            niv[i][1] = min(niv[i][1], niv[j][0])


viz = []
ls = []
niv = []
m_c = []

if __name__ == "__main__":
    ls = ls_adiacenta("graf_crit.txt")
    viz = [0]*len(ls)
    nivel = 0
    niv = [[0, 0]] * len(ls)
    for i in range(len(ls)):
        if viz[i] == 0:
            DFS(nivel, i)
    print(m_c)
