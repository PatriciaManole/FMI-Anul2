def ls_adiacenta(fisier, tip):
    f = open(fisier, 'r')
    vf, muchii = [int(x) for x in f.readline().rstrip().split()]
    ls = [[] for i in range(vf)]
    for aux in f:
        muchii -= 1
        aux = aux.rstrip().split()
        i = int(aux[0])
        j = int(aux[1])
        ls[i-1].append(j-1)
        if tip == "n":
            ls[j-1].append(i-1)
        if muchii == 0:
            break
    f.close()
    return ls

def DFS(i, ls):
    viz[i] = 1
    ord_gasit.append(i)
    for j in ls[i]:
        if viz[j] == 0:
            tata[j] = i
            DFS(j, ls)
        elif j not in fin:
            if tip == "n" and tata[i] != j:
                intoarcere.append([i+1, j+1])
            elif tip != "n":
                intoarcere.append([i + 1, j + 1])
        elif j in fin and ord_gasit.index(i) < ord_gasit.index(j):
            avansare.append([i+1, j+1])
        else:
            traversare.append([i+1, j+1])
    fin.append(i)


intoarcere = []
traversare = []
avansare = []

tip = ""
viz = []
tata = []
fin = []
ord_gasit = []

if __name__ == "__main__":
    tip = input("Introduceti tipul grafului [orientat(o) sau neorientat(n)] : ")
    if tip != "o" and tip != "n":
        print(tip, "nu este un tip corect")
        exit(0)
    ls = ls_adiacenta("graf3.txt", tip)
    viz = [0]*len(ls)
    tata = [-1]*len(ls)
    for i in range(len(viz)):
        if viz[i] == 0:
            DFS(i, ls)
    print("intoarcere : ", end="")
    for x in intoarcere:
        print(x, end=" ")
    print("\ntraversare : ", end="")
    for x in traversare:
        print(x, end=" ")
    print("\navansare : ", end="")
    for x in avansare:
        print(x, end=" ")
