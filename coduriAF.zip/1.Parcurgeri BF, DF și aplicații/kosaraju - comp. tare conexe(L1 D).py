def ls_adiacenta(fisier):
    f = open(fisier, 'r')
    nr_vf, muchii = [int(x) for x in f.readline().rstrip().split()]
    lista_ad = [[] for i in range(nr_vf)]
    for aux in f:
        muchii -= 1
        aux = aux.rstrip().split()
        i = int(aux[0])
        j = int(aux[1])
        lista_ad[i-1].append(j)
        if muchii == 0:
            break
    f.close()
    return lista_ad

def DFS(x, ls, viz):
    viz[x] = 1
    for y in ls[x]:
        if viz[y-1] == 0:
            DFS(y-1, ls, viz)
    fin.append(x+1)

def ls_transpus(ls):
    ls_tr = [[] for i in range(len(ls))]
    for x in range(len(ls)):
        for y in ls[x]:
            ls_tr[y-1].append(x+1)
    return ls_tr


ls = ls_adiacenta("kosaraju.in")
fin = []
viz = [0]*len(ls)

if __name__ == '__main__' :
    for i in range(len(viz)):
        if viz[i] == 0:
            DFS(i, ls, viz)
    print("Ordine finalizare :", fin, sep="\n")
    ls_tr = ls_transpus(ls)
    kosaraju = []
    viz = [0] * len(ls)
    fin_aux = fin
    fin = []
    print("Componente tare conexe :")
    while fin_aux:
        vf = fin_aux.pop()
        DFS(vf-1, ls_tr, viz)
        fin.reverse()
        print(fin)
        for elem in fin:
            if elem in fin_aux:
                fin_aux.remove(elem)
        fin = []
