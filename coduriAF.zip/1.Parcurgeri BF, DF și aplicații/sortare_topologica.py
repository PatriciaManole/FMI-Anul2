def ls_adiacenta(fisier):
    ls = []
    f = open(fisier, 'r')
    aux = f.readline().rstrip().split()
    muchii = int(aux[1])
    aux = int(aux[0])
    for x in range(0, aux):
        ls.append([])
    for aux in f:
        muchii -= 1
        aux.rstrip()
        i = int(aux[0])
        j = int(aux[2])
        ls[i-1].append(j)
        if muchii == 0:
            break
    f.close()
    return ls

def gr_int(ls):
    grade_int = []
    for x in range(1, len(ls)+1):
        grad = 0
        for i in ls:
            for j in i:
                if j == x:
                    grad+=1
        grade_int.append(grad)
    return grade_int

if __name__ == '__main__' :
    ls = ls_adiacenta("graf1.txt")
    grade_int = gr_int(ls)
    coada = []
    for i in range(0, len(grade_int)):
        if grade_int[i] == 0:
            coada.append(i+1)
    vf_gasite = len(coada)
    i = 0
    while vf_gasite != len(ls):
        vecini = ls[coada[i]-1]
        for elem in vecini:
            grade_int[elem-1] -= 1
        for j in range(0, len(grade_int)):
            if grade_int[j] == 0 and j + 1 not in coada:
                coada.append(j + 1)
                vf_gasite += 1
        i += 1
    print(coada)
