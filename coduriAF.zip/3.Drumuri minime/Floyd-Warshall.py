#pt graf orientat, distantele de la un varf dat la celelalte varfuri, ponderi negative, cu cicluri negative
def floyd_warshall(s):
    global d, n, la
    for i in range(1, n+1):
        for j in range(1, n+1):
            d[i][j] = la[i][j]
            if la[i][j] == float('inf'):
                p[i][j] = 0
            else:
                p[i][j] = i
    for k in range(1, n+1):
        for i in range(1, n+1):
            for j in range(1, n+1):
                if d[i][j] > d[i][k] + d[k][j]:
                    d[i][j] = d[i][k] + d[k][j]
                    p[i][j] = p[k][j]


f = open("Floyd-Warshall.txt")
n, m = [int(x) for x in f.readline().split()]
la = [[float('inf') for i in range(n+1)] for i in range(n+1)]
for i in range(n+1):
    la[i][i] = 0
for linie in f:
    ls = linie.split()
    la[int(ls[0])][int(ls[1])] = int(ls[2])
f.close()
d = [[0 for i in range(n+1)] for i in range(n+1)]
p = [[0 for i in range(n+1)] for i in range(n+1)]
s = int(input(f"Introdu varful de start s[1 <= s <= {n}] : "))
floyd_warshall(s)
for vf in range(1, n+1):
    if vf != s:
        if d[vf] == float('inf'):
            print(f"\nNu se poate ajunge de la varful {s} la varful {vf}.")
        else:
            print(f"\nDistanta minima de la varful {s} la varful {vf} este {d[s][vf]}.")
