def gr_int(ls):
    grade_int = []
    for x in range(1, len(ls)+1):
        grad = 0
        for i in ls:
            for j in i:
                if j[0] == x:
                    grad += 1
        grade_int.append(grad)
    return grade_int

def sort_topologica(ls):
    grade_int = gr_int(ls[:len(ls)-1])
    grade_int.insert(0, 0)
    coada = []
    for i in range(len(grade_int)):
        if grade_int[i] == 0:
            coada.append(i)
    vf_gasite = len(coada)
    i = 0
    while vf_gasite != len(ls):
        vecini = []
        for elem in ls[coada[i]]:
            vecini.append(elem[0])
        for elem in vecini:
            grade_int[elem] -= 1
        for j in range(0, len(grade_int)):
            if grade_int[j] == 0 and j not in coada:
                coada.append(j)
                vf_gasite += 1
        i += 1
    return coada

def DAG(s):
    global tata, d, la
    for u in range(n+2):
        d[u] = float('-inf')
        tata[u] = 0
    d[s] = 0
    sort_top = sort_topologica(la)
    for u in sort_top:
        for v in la[u]:
            if d[v[0]] < d[u] + v[1]:
                d[v[0]] = d[u] + v[1]
                tata[v[0]] = u


f = open("activitati.txt")
n = int(f.readline().rstrip('\n'))
durate = [int(x) for x in f.readline().split()]
m = int(f.readline().rstrip('\n'))
la = [[] for i in range(n+2)]
for linie in f:
    ls = linie.split()
    la[int(ls[0])].append([int(ls[1]), durate[int(ls[0])-1]])
f.close()
grade = gr_int(la[1:n+1])
for i in range(n):
    if grade[i] == 0:
        la[0].append([i+1, 0])
for i in range(1, n+1):
    if len(la[i]) == 0:
        la[i].append([n+1, durate[i-1]])
tata = [0]*(n+2)
d = [0]*(n+2)
DAG(0)
max = d[0]
for i in d:
    if max < i:
        max = i
print(f"Timp minim {max}")
act_crit = []
x = n+1
while tata[x] != 0:
    x = tata[x]
    act_crit.insert(0, x)
print(f"Activitati critice: {act_crit}")
for i in range(1,n+1):
    print(f"{i}: ({d[i]}, {d[i]+durate[i-1]})")
