# Prob. lab 4 folosind Dijkstra, modificand Prim
import heapq


def dijkstra(s):
    global la, d, tata
    viz = [0]*(n+1)
    d = [float('inf')]*(n+1)
    tata = [0]*(n+1)
    h = []
    d[s] = 0
    heapq.heappush(h, (d[s], s))
    while len(h) > 0:
        c, u = heapq.heappop(h)
        if viz[u] == 0:
            viz[u] = 1
            for v, c in la[u]:
                if viz[v] == 0:
                    if d[v] > d[u] + c:
                        d[v] = d[u] + c
                        tata[v] = u
                        heapq.heappush(h, (c, v))
        else:
            continue


f = open("grafpond.in")
n, m = [int(x) for x in f.readline().split()]
la = [[] for i in range(n+1)]
for linie in f:
    ls = linie.split()
    la[int(ls[0])].append([int(ls[1]), int(ls[2])])
    la[int(ls[1])].append([int(ls[0]), int(ls[2])])
f.close()
d = []
tata = []
s = int(input(f"Introdu varful de start s[1 <= s <= {n}] : "))
print(f"Introduceti punctele de control[valori intre 1 si {n}] :")
k = list(map(int, input().split()))
k = list(set(k))
vect_pct = [False]*(n+1)
for pct in k:
    vect_pct[pct] = True
dijkstra(s)
d_min = float('inf')
index_min = -1
for i in range(1, len(d)):
    if d[i] < d_min and vect_pct[i] and i != s:
        d_min = d[i]
        index_min = i
lant_min = []
print("Cel mai apropiat punct de control : ", index_min)
while index_min != s:
    lant_min.append(index_min)
    index_min = tata[index_min]
lant_min.append(index_min)
print("Distanta : ", d_min)
print("Lant : ", lant_min)
