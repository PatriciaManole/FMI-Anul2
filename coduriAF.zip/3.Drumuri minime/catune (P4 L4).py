import heapq


def dijkstra(s):
    global la, d, tata
    viz = [0]*(n+1)
    d = [float('inf')]*(n+1)
    tata = [0]*(n+1)
    h = []
    d[s] = 0
    heapq.heappush(h, (d[s], s))
    while len(h) > 0:
        c, u = heapq.heappop(h)
        if viz[u] == 0:
            viz[u] = 1
            for v, c in la[u]:
                if viz[v] == 0:
                    if d[v] > d[u] + c:
                        d[v] = d[u] + c
                        if u == 0:
                            tata[v] = v
                        else:
                            tata[v] = tata[u]
                        heapq.heappush(h, (d[v], v))
        else:
            continue


tip = input("Introdu tipul grafului(n/o) : ")
f = open("catune.txt")
n, m, nr = [int(x) for x in f.readline().split()]
fortarete = [int(x) for x in f.readline().split()]
la = [[] for i in range(n+1)]
for linie in f:
    ls = linie.split()
    la[int(ls[0])].append([int(ls[1]), int(ls[2])])
    if tip == "n":
        la[int(ls[1])].append([int(ls[0]), int(ls[2])])
f.close()
if len(fortarete) != nr:
    exit(0)
d = []
tata = []
for vf in fortarete:
    la[0].append([vf, 0])
dijkstra(0)
for vf in fortarete:
    tata[vf] = 0
tata = tata[1:]
print(tata)
