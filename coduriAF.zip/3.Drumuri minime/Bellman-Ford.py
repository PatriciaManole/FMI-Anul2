#pt graf orientat, distantele de la un varf dat la celelalte varfuri, ponderi negative
def bellman_ford(s):
    global muchii, d, tata, n
    d = [float('inf')]*(n+1)
    tata = [0]*(n+1)
    d[s] = 0
    for i in range(1, n):
        for u, v, c in muchii:
            if d[v] > d[u] + c:
                d[v] = d[u] + c
                tata[v] = u
    #detectare circuite negative(pt. validare corectitudine Bellman-Ford)
    for u, v, c in muchii:
        if d[v] > d[u] + c:
            d[v] = d[u] + c
            tata[v] = u
            print("Bellman-Ford nu poate fi aplicat(circuit negativ gasit).")
            x = v
            for i in range(1, n + 1):
                x = tata[x]
            circuit = [x]
            aux = x
            x = tata[x]
            while x != aux:
                circuit.append(x)
                x = tata[x]
            print(circuit)
            exit(0)


tip = input("Introdu tipul grafului(n/o) : ")
f = open("Bellman-Ford.txt")
n, m = [int(x) for x in f.readline().split()]
muchii = []
for linie in f:
    ls = linie.split()
    muchii.append([int(ls[0]), int(ls[1]), int(ls[2])])
    if tip == "n":
        muchii.append([int(ls[1]), int(ls[0]), int(ls[2])])
f.close()
d = []
tata = []
s = int(input(f"Introdu varful de start s[1 <= s <= {n}] : "))
print(f"Introduceti varfurile destinatie[valori intre 1 si {n}] :")
k = list(map(int, input().split()))
k = list(set(k))
bellman_ford(s)
for vf in k:
    if d[vf] == float('inf'):
        print(f"\nNu se poate ajunge de la varful {s} la varful {vf}.")
    else:
        print(f"\nDistanta minima de la varful {s} la varful {vf} este {d[vf]}.")
        lant = [vf]
        i = vf
        while i != s:
            i = tata[i]
            lant.append(i)
        lant.reverse()
        print(f"Lantul minim de la varful {s} la varful {vf} este {lant}.")

