#Drumuri minime de sursa unica in grafuri fara circuite(DAG) cu ponderi reale
#ipoteza : Graful nu are circuite

def gr_int(ls):
    grade_int = []
    for x in range(len(ls)):
        grad = 0
        for i in ls:
            for j in i:
                if j[0] == x:
                    grad += 1
        grade_int.append(grad)
    return grade_int

def sort_topologica(ls):
    grade_int = gr_int(ls)
    coada = []
    for i in range(len(grade_int)):
        if grade_int[i] == 0:
            coada.append(i)
    vf_gasite = len(coada)
    i = 0
    while vf_gasite != len(ls):
        vecini = []
        for elem in ls[coada[i]]:
            vecini.append(elem[0])
        for elem in vecini:
            grade_int[elem] -= 1
        for j in range(0, len(grade_int)):
            if grade_int[j] == 0 and j not in coada:
                coada.append(j)
                vf_gasite += 1
        i += 1
    return coada

def DAG(s):
    global tata, d, la
    s -= 1
    for u in range(n):
        d[u] = float('inf')
        tata[u] = 0
    d[s] = 0
    sort_top = sort_topologica(la)
    for u in sort_top:
        for v in la[u]:
            if d[v[0]] > d[u] + v[1]:
                d[v[0]] = d[u] + v[1]
                tata[v[0]] = u


f = open("DAG_1.txt")
n, m = [int(x) for x in f.readline().split()]
la = [[] for i in range(n)]
for linie in f:
    ls = linie.split()
    la[int(ls[0])-1].append([int(ls[1])-1, int(ls[2])])
f.close()
tata = [0]*n
d = [0]*n
s = int(input(f"Introdu varful de start [intre 1 si {n}] : "))
if s < 1 or s > n:
    exit(0)
DAG(s)
print(d)
