def initializare(u):
    tata[u] = 0
    d[u] = float('inf')

def prim(s):
    global Q, d, tata, muchii
    Q = [0]*(n+1)
    d = [0]*(n+1)
    tata = [0]*(n+1)
    for u in range(1, n+1):
        initializare(u)
    d[s] = 0
    while Q:
        et_min = float('inf')
        u = 0
        for vf in range(1, len(Q)):
            if d[vf] < et_min and Q[vf] == 0:
                et_min = d[vf]
                u = vf
        Q[u] = 1
        for muchie in muchii:
            if u == muchie[0]:
                if Q[muchie[1]] == 0 and muchie[2] < d[muchie[1]]:
                    d[muchie[1]] = muchie[2]
                    tata[muchie[1]] = u
            elif u == muchie[1]:
                if Q[muchie[0]] == 0 and muchie[2] < d[muchie[0]]:
                    d[muchie[0]] = muchie[2]
                    tata[muchie[0]] = u
        if u != s:
            print(u, tata[u])
        toate_vf_parcurse = True
        for i in range(1, len(Q)):
            if Q[i] == 0:
                toate_vf_parcurse = False
                break
        if toate_vf_parcurse:
            break


tata = []
d = []
Q = []
f = open("graf_ponderat_3.txt")
muchii = []
n, m = [int(x) for x in f.readline().split()]
for linie in f:
    ls = linie.split()
    muchii.append((int(ls[0]), int(ls[1]), int(ls[2])))
f.close()
s = int(input(f"Introdu varful de start (de la 1 la {n}) : "))
prim(s)
