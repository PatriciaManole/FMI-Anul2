# O(mlogn)

import heapq


def prim(s):
    global la
    viz = [0]*(n+1)
    d = [float('inf')]*(n+1)
    tata = [0]*(n+1)
    h = []
    d[s] = 0
    heapq.heappush(h, (d[s], s))
    for i in range(n):
        c, u = heapq.heappop(h)
        while viz[u] == 1:
            c, u = heapq.heappop(h)
        viz[u] = 1
        for v, c in la[u]:
            if viz[v] == 0:
                if d[v] > c:
                    d[v] = c
                    tata[v] = u
                    heapq.heappush(h,(c,v))
    cost_total = 0
    for u in range(1,n+1):
        if tata[u] != 0:
            print(u, tata[u])
            cost_total += d[u]
    print("cost_total ", cost_total)


f = open("graf_ponderat_3.txt")
n, m = [int(x) for x in f.readline().split()]
la = [[] for i in range(n+1)]
for linie in f:
    ls = linie.split()
    la[int(ls[0])].append([int(ls[1]), int(ls[2])])
    la[int(ls[1])].append([int(ls[0]), int(ls[2])])
f.close()
prim(1)
