def levenshtein(cuv1, cuv2):  #pt.operatiuni cu acelasi cost(1)
    if len(cuv1) == 0:
        return len(cuv2)
    elif len(cuv2) == 0:
        return len(cuv1)
    a = []
    for i in range(len(cuv1) + 1):
        linie = [0] * (len(cuv2) + 1)
        for j in range(len(cuv2) + 1):
            if i != 0 or j != 0:
                if i == 0:
                    linie[j] = linie[j-1] + 1
                elif j == 0:
                    linie[0] = a[i-1][j] + 1
        a.append(linie)
    for i in range(1, len(cuv1) + 1):
        for j in range(1, len(cuv2) + 1):
            if cuv1[i-1] == cuv2[j-1]:
                a[i][j] = a[i-1][j-1]
            else:
                x = a[i][j-1] + 1
                y = a[i-1][j] + 1
                z = a[i-1][j-1] + 1
                if x <= y and x <= z:
                    a[i][j] = x
                elif y <= x and y <= z:
                    a[i][j] = y
                else:
                    a[i][j] = z
    return a[len(cuv1)][len(cuv2)]

def initializare(u):
    comp[u-1] = u

def reuniune(u,v):
    x, y = comp[u], comp[v]
    for i in range(0, len(comp)):
        if comp[i] == y:
            comp[i] = x

def kruskal():
    global comp
    comp = [0]*n
    nr_comp = n

    muchii.sort(key=lambda x: x[2])
    for u in range(1, n+1):
        initializare(u)

    for e in muchii:
        if comp[e[0]-1] != comp[e[1]-1]:
            reuniune(e[0]-1, e[1]-1)
            nr_comp -= 1
            if nr_comp == k:
                break


cuvinte = []

f = open("cuvinte.in")
for linie in f:
    linie = linie.split()
    for cuv in linie:
        cuvinte.append(cuv)
f.close()

k = int(input(f"Introdu k(1<=k<={len(cuvinte)}) : "))
muchii = []

for i in range(0, len(cuvinte) - 1):
    for j in range(i+1, len(cuvinte)):
        d = levenshtein(cuvinte[i], cuvinte[j])
        muchii.append([i+1, j+1, d])

comp = []
n = len(cuvinte)
m = len(muchii)

if k == n:
    for elem in cuvinte:
        print([elem])
elif k <= 0 or k > len(cuvinte):
    print("k nevalid")
else:
    kruskal()
    aux = []
    for x in comp:
        if x not in aux:
            aux.append(x)
    vf_con = [[] for x in aux]
    for i in range(0, len(aux)):
        for j in range(0, len(comp)):
            if comp[j] == aux[i]:
                vf_con[i].append(j+1)
    cuv_con = []
    for elem in vf_con:
        cuv = []
        for x in elem:
            cuv.append(cuvinte[x-1])
        cuv_con.append(cuv)
    print(cuv_con)
    print("Grad de separare =", end=" ")
    grad_sep = float('inf')
    for elem in muchii:
        if comp[elem[0]-1] != comp[elem[1]-1]:
            grad_sep = min(grad_sep, elem[2])
    print(grad_sep)
