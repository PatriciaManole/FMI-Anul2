def initializare(u):
    tata[u] = 0
    h[u] = 0

def reprez(u):
    if tata[u] == 0:
        return u
    tata[u] = reprez(tata[u])
    return tata[u]

def reuniune(u, v):
    ru = reprez(u)
    rv = reprez(v)
    if h[ru] > h[rv]:
        tata[rv] = ru
    else:
        tata[ru] = rv
        if h[ru] == h[rv]:
            h[rv] += 1

def kruskal():
    global tata, h
    tata = [0]*(n+1)
    h = [0]*(n+1)
    nr_muchii = 0

    muchii.sort(key = lambda x:x[2])
    for u in range(1, n+1):
        initializare(u)
    
    for e in muchii:
        if reprez(e[0]) != reprez(e[1]):
            reuniune(e[0], e[1])
            print(e[0], e[1], "cost :", e[2])
            nr_muchii += 1
            if nr_muchii == k:
                break


tata = []
h = []
f = open("graf.in")
muchii = []
n,m = [int(x) for x in f.readline().split()]
for linie in f:
    ls = linie.split()
    muchii.append((int(ls[0]), int(ls[1]), int(ls[2])))
f.close()
k = int(input(f"Introdu numarul de muchii [1<=k<={n-1}]: "))
if k >= 1:
    kruskal()
