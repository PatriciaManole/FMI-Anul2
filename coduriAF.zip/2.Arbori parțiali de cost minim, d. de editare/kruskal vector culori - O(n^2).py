#varianta vector culori
def initializare(u):
    comp[u-1] = u

def reuniune(u,v):
    x, y = comp[u], comp[v]
    for i in range(0, len(comp)):
        if comp[i] == y:
            comp[i] = x

def kruskal():
    global comp,k
    comp = [0]*n
    nr_muchii = 0

    muchii.sort(key = lambda x:x[2])
    for u in range(1, n+1):
        initializare(u)
    
    for e in muchii:
        if comp[e[0]-1] != comp[e[1]-1]:
            reuniune(e[0]-1, e[1]-1)
            print(e[0], e[1], "cost :", e[2])
            nr_muchii += 1
            if nr_muchii == k:
                break


muchii = []
f=open("graf.in")
n, m = [int(x) for x in f.readline().split()]
for linie in f:
    ls = linie.split()
    muchii.append((int(ls[0]), int(ls[1]), int(ls[2])))
f.close()
k = int(input(f"Introdu numarul de muchii [1<=k<={n-1}]: "))
if k >= 1:
    kruskal()
