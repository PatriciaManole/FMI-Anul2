# var mai ineficienta dupa timp (alg.prim + comparatie intre muchii)
import heapq


def prim(s):
    global la, muchii_apcm
    viz = [0]*(n+1)
    d = [float('inf')]*(n+1)
    tata = [0]*(n+1)
    h = []
    d[s] = 0
    heapq.heappush(h, (d[s], s))
    for i in range(n):
        c, u = heapq.heappop(h) #
        while viz[u] == 1:
            c, u = heapq.heappop(h)
        viz[u] = 1
        for v, c in la[u]:
            if viz[v] == 0:
                if d[v] > c:
                    d[v] = c
                    tata[v] = u
                    heapq.heappush(h, (c, v))
    for u in range(1, n+1):
        if tata[u] != 0:
            muchii_apcm.append([u, tata[u], d[u]])

def reuniune(u, v, v_cul):
    x, y = v_cul[u], v_cul[v]
    for i in range(0, len(v_cul)):
        if v_cul[i] == y:
            v_cul[i] = x

def comp_conexe(muchii):
    v_comp = [i for i in range(1, n+1)]
    for m in muchii:
        if v_comp[m[0]-1] != v_comp[m[1]-1]:
            reuniune(m[0]-1, m[1]-1, v_comp)
    aux = list(set(v_comp))
    multimi = [[], []]
    for i in range(n):
        if v_comp[i] == aux[0]:
            multimi[0].append(i+1)
        else:
            multimi[1].append(i+1)
    return multimi


# parte Prim
f = open("second_best_1.txt")
n, m = [int(x) for x in f.readline().split()]
la = [[] for i in range(n+1)]
muchii_apcm = []
muchii_rest = []
for linie in f:
    ls = linie.split()
    muchii_rest.append([int(ls[0]), int(ls[1]), int(ls[2])])
    la[int(ls[0])].append([int(ls[1]), int(ls[2])])
    la[int(ls[1])].append([int(ls[0]), int(ls[2])])
f.close()
prim(1)
# parte 2nd best

# eliminare muchii din apcm
for m in muchii_apcm:
    if m in muchii_rest:
        muchii_rest.remove(m)
    else:
        muchii_rest.remove([m[1], m[0], m[2]])
# comparatii intre muchii si simulare apcm fara o muchie
apcm_nou = []
c_min = float('inf')
for i in range(len(muchii_apcm)):
    muchii_apcm_partial = []
    for elem in muchii_apcm:
        muchii_apcm_partial.append(elem)
    c_vechi = muchii_apcm_partial[i][2]
    del muchii_apcm_partial[i]
    comp = comp_conexe(muchii_apcm_partial)
    for m in muchii_rest:
        if (m[0] in comp[0] and m[1] in comp[1]) or (m[0] in comp[1] and m[1] in comp[0]):
            if m[2]-c_vechi < c_min:
                c_min = m[2]-c_vechi
                apcm_nou = muchii_apcm_partial
                apcm_nou.append(m)
cost_total = 0
print("Second best : ")
for m in apcm_nou:
    print(f'{m[0]} {m[1]} cost : {m[2]}')
    cost_total += m[2]
print(f'Cost total : {cost_total}')
