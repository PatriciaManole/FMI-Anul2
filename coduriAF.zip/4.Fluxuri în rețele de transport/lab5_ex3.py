def verif():
    if len(gr_int) != len(gr_ext) or len(gr_ext) != n:
        return False
    s1 = 0
    s2 = 0
    for i in range(len(gr_int)):
        s1 += gr_int[i]
        s2 += gr_ext[i]
    return True if s1 == s2 else False

def constr_retea(n):
    global retea
    retea = [[0 for i in range(2*n+2)]for i in range(2*n+2)]
    for i in range(n):
        retea[0][i+1] = gr_ext[i]
        retea[n+1+i][2*n+1] = gr_int[i]
        for j in range(n):
            if i != j:
                retea[i+1][n+j+1] = 1

def BFS(s, t, tata):
    viz = [False] * (2*n+2)
    q = [s]
    viz[s] = True
    while q:
        u = q.pop(0)
        for v in range(2*n+2):
            c = retea[u][v]
            if not viz[v] and c > 0:
                q.append(v)
                viz[v] = True
                tata[v] = u
                if v == t:
                    return True
    return False

def det_flux_max(): #Ford_FUlkerson
    tata = [-1]*(2*n+2)
    ls = []
    while BFS(0, 2*n+1, tata):
        f_curent = float('inf')
        vf = 2*n+1
        muchie = []
        while vf != 0:
            f_curent = min(f_curent, retea[tata[vf]][vf])
            if vf != 2*n+1 and vf != 2*n+1 != 0:
                muchie.append(vf)
            vf = tata[vf]
        muchie.reverse()
        ls.append(muchie)
        vf = 2*n+1
        while vf != 0:
            u = tata[vf]
            retea[u][vf] -= f_curent
            retea[vf][u] += f_curent
            vf = tata[vf]
    return ls


f = open("secvente.in")
n = int(f.readline().split()[0])
gr_int = [int(x) for x in f.readline().split()]
gr_ext = [int(x) for x in f.readline().split()]
f.close()
if not verif():
    print("NU")
else:
    constr_retea(n)
    ls = det_flux_max()
    for i in range(len(ls)):
        for j in range(len(ls[i])):
            if ls[i][j] > n:
                ls[i][j] -= n
    ls_aux = []
    for i in range(len(ls)):
        if len(ls[i]) == 2:
            ls_aux.append(ls[i])
        else:
            j = 0
            while j != (len(ls[i]) - 1):
                if j % 2 == 0:
                    ls_aux.append([ls[i][j], ls[i][j+1]])
                else:
                    ls_aux.remove([ls[i][j+1], ls[i][j]])
                j += 1
    print("Graful va avea arcele:")
    for i, j in ls_aux:
        print(i, j)
