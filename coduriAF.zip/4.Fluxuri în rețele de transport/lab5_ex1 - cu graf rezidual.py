from queue import Queue


def flux_maxim(flux):
    global n
    v_max = 0
    for i in range(n+1):
        for j in range(n+1):
            if flux[i][j] > v_max:
                v_max = flux[i][j]
    return v_max

def verif_flux(s, t, flux, retea):
    global n
    g_int = [0]*(n+1)
    g_ext = [0]*(n+1)
    for i in range(n+1):
        for j in range(n+1):
            if flux[i][j] > retea[i][j]:
                return False
            g_int[j] += flux[i][j]
            g_ext[i] += flux[i][j]
    for i in range(n+1):
        if i != s and i != t and g_int[i] != g_ext[i]:
            return False
    return True

def BFS(s, t, tata):
    global n, graf_rezid
    for i in range(n+1):
        tata[i] = 0
    viz = [False] * (n+1)
    q = Queue(maxsize=n)
    q.put(s)
    viz[s] = True
    while not q.empty():
        i = q.get()
        for j in range(1, n+1):
            if graf_rezid[i][j] > 0 and not viz[j]:
                q.put(j)
                viz[j] = True
                tata[j] = i
                if j == t:
                    return True

def Edmonds_Karp(s, t):
    global flux, graf_rezid, n, arc_inv
    tata = [0]*(n+1)
    f_max = flux_maxim(flux)
    while BFS(s, t, tata):
        vf = t
        f_curent = float('inf')
        while vf != s:
            f_curent = min(f_curent, graf_rezid[tata[vf]][vf])
            vf = tata[vf]
        f_max += f_curent
        vf = t
        while vf != s:
            u = tata[vf]
            graf_rezid[u][vf] -= f_curent
            graf_rezid[vf][u] += f_curent
            vf = tata[vf]
    print("Fluxul maxim :", f_max)
    viz = [False] * (n+1)
    q = Queue(maxsize=n)
    q.put(n)
    viz[s] = True
    while not q.empty():
        i = q.get()
        if viz[i]:
            continue
        for j in range(1, n):
            if graf_rezid[i][j] > 0:
                if not viz[j] and j != 1:
                    q.put(j)
                if (not viz[j] or j == s) and arc_inv[i][j]:
                    if j == s:
                        print('s', i, graf_rezid[i][j])
                    elif i == t:
                        print(j, 't', graf_rezid[i][j])
                    else:
                        print(j, i, graf_rezid[i][j])
        viz[i] = True
    print("Taietura minima :", f_max)
    arce = []
    viz = [False] * (n+1)
    q = Queue(maxsize=n)
    q.put(s)
    viz[s] = True
    while not q.empty():
        i = q.get()
        for j in range(1, n + 1):
            if graf_rezid[i][j] > 0 and not viz[j]:
                q.put(j)
                viz[j] = True
            elif graf_rezid[j][i] > 0 and not viz[j]:
                arce.append([i, j])
                viz[j] = True
    for i, j in arce:
        print(i, j)


f = open("retea.in")
n = int(f.readline().split()[0])
s, t = [int(x) for x in f.readline().split()]
m = int(f.readline().split()[0])
retea = [[0 for i in range(n+1)]for i in range(n+1)]
flux = [[0 for i in range(n+1)]for i in range(n+1)]
muchii = []
for linie in f:
    ls = linie.split()
    retea[int(ls[0])][int(ls[1])] = int(ls[2])
    flux[int(ls[0])][int(ls[1])] = int(ls[3])
    muchii.append([int(ls[0]), int(ls[1])])
f.close()
if verif_flux(s, t, flux, retea):
    print("DA")
else:
    print("NU")
    exit(0)
graf_rezid = [[0 for i in range(n+1)]for i in range(n+1)]
arc_inv = [[False for i in range(n+1)]for i in range(n+1)]
for i, j in muchii:
    graf_rezid[i][j] = retea[i][j] - flux[i][j]
    graf_rezid[j][i] = flux[i][j]
    arc_inv[j][i] = True
Edmonds_Karp(s, t)
