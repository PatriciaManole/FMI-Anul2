from queue import Queue


def constr_retea(retea):
    global v_cul
    v_cul = [0]*(n+1)
    tata = [-1]*(n+1)
    viz = [False]*(n+1)
    q = Queue(maxsize=n)
    q.put(1)
    viz[1] = True
    v_cul[1] = 1
    while not q.empty():
        i = q.get()
        for j in range(len(retea[i])):
            if retea[i][j] != 0 : 
                if not viz[j]:
                    q.put(j)
                    viz[j] = True
                    tata[j] = i
                if v_cul[i] == v_cul[j]:
                    print("Graful nu este bipartit")
                    '''
                    print("Ciclu impar : ")
                    ciclu = [[i, j]]
                    while i != j:
                        ciclu.append([i, tata[i]])
                        ciclu.append([j, tata[j]])
                        i = tata[i]
                        j = tata[j]
                    print(ciclu)
                    return False
                    '''
                elif v_cul[i] == 1:
                    v_cul[j] = 2
                else:
                    v_cul[j] = 1
    for i in range(len(v_cul)):
        if v_cul[i] == 1:
            retea[0][i] = 1
        elif v_cul[i] == 2:
            retea[i][n+1] = 1
    for i in range(1, len(retea)-1):
        for j in range(1, len(retea)-1):
            if v_cul[i] == 2 and v_cul[j] == 1:
                retea[i][j] = 0
    return True

def BFS(retea):
    for i in range(n+2):
        tata[i] = -1
    viz = [False]*(n+2)
    q = Queue(maxsize=(n+2))
    q.put(0)
    viz[0] = True
    while not q.empty():
        i = q.get()
        for j in range(1, n+2):
            if retea[i][j] > 0 and not viz[j] and retea[i][j] - flux[i][j] > 0:
                q.put(j)
                viz[j] = True
                tata[j] = i
                if j == n+1:
                    return True
        for j in range(1, n+2):
            if retea[j][i] > 0 and not viz[j] and flux[j][i] > 0:
                q.put(j)
                viz[j] = True
                tata[j] = -i
                if j == n+1:
                    return True

def cuplaj_max(flux, retea):
    global tata
    tata = [-1]*(n+2)
    while BFS(retea):
        vf = n+1
        drum = [vf]
        while vf != 0:
            if tata[vf] >= 0:
                vf = tata[vf]
                drum.append(vf)
            else:
                vf = -tata[vf]
                drum.append(vf)
        drum.reverse()
        cuplaje.append(drum[1:len(drum)-1])
        vf = n+1
        while vf != 0:
            if tata[vf] >= 0:
                u = tata[vf]
                flux[u][vf] += 1
                vf = u
            else:
                u = -tata[vf]
                flux[vf][u] -= 1
                vf = u


f = open("graf.in")
n, m = [int(x) for x in f.readline().split()]
flux = [[0 for i in range(n+2)]for i in range(n+2)]
retea = [[0 for i in range(n+2)]for i in range(n+2)]
for linie in f:
    ls = linie.split()
    retea[int(ls[0])][int(ls[1])] = 1
    retea[int(ls[1])][int(ls[0])] = 1
f.close()
constr_retea(retea)
cuplaje = []
cuplaj_max(flux, retea)

for i in cuplaje:
    print(i)
