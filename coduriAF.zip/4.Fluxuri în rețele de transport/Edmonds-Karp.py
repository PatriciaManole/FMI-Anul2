def BFS(s, t, flux, tata):
    global n, mat
    for i in range(n):
        tata[i] = 0
    viz = [False] * n
    q = [s]
    viz[s] = True
    while q:
        i = q.pop(0)
        for j in range(n):
            if mat[i][j] > 0 and not viz[j] and mat[i][j]-flux[i][j] > 0:
                q.append(j)
                viz[j] = True
                tata[j] = i
                if j == t:
                    return True
        for j in range(n):
            if mat[j][i] > 0 and not viz[j] and flux[j][i] > 0:
                q.append(j)
                viz[j] = True
                tata[j] = -i
                if j == t:
                    return True
    return False

def Edmonds_Karp(s, t):
    global n
    flux = [[0 for i in range(n)]for i in range(n)]
    tata = [-1] * n
    f_max = 0
    while BFS(s, t, flux, tata):
        f_curent = float('inf')
        vf = t
        while vf != s:
            if tata[vf] >= 0:
                f_curent = min(f_curent, mat[tata[vf]][vf] - flux[tata[vf]][vf])
                vf = tata[vf]
            else:
                f_curent = min(f_curent, flux[vf][-tata[vf]])
                vf = -tata[vf]
        f_max += f_curent
        vf = t
        while vf != s:
            if tata[vf] >= 0:
                u = tata[vf]
                flux[u][vf] += f_curent
                vf = tata[vf]
            else:
                u = -tata[vf]
                flux[vf][u] -= f_curent
                vf = -tata[vf]
    print("Fluxul maxim :", f_max)
    for i in range(n):
        for j in range(n):
            if flux[i][j] != 0:
                if i == 0:
                    print('s', j, flux[i][j])
                elif j == n-1:
                    print(i, 't', flux[i][j])
                else:
                    print(i, j, flux[i][j])

f = open("retea1_EK.txt")
n, m = [int(x) for x in f.readline().split()]
s, t = [int(x) for x in f.readline().split()]
mat = [[0 for i in range(n)]for i in range(n)]
for linie in f:
    ls = linie.split()
    mat[int(ls[0])][int(ls[1])] = int(ls[2])
f.close()
Edmonds_Karp(s, t)