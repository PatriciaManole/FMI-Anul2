from queue import Queue


def verif_flux(s, t, flux, retea):
    global n
    g_int = [0]*(n+1)
    g_ext = [0]*(n+1)
    for i in range(n+1):
        for j in range(n+1):
            if flux[i][j] > retea[i][j]:
                return False
            g_int[j] += flux[i][j]
            g_ext[i] += flux[i][j]
    for i in range(n+1):
        if i != s and i != t and g_int[i] != g_ext[i]:
            return False
    return True

def flux_maxim(flux):
    global n
    v_max = 0
    for i in range(n+1):
        for j in range(n+1):
            if flux[i][j] > v_max:
                v_max = flux[i][j]
    return v_max

def BFS(s, t, flux, tata):
    global n, retea
    for i in range(n+1):
        tata[i] = 0
    viz = [False] * (n+1)
    q = Queue(maxsize=n)
    q.put(s)
    viz[s] = True
    while not q.empty():
        i = q.get()
        for j in range(1, n+1):
            if retea[i][j] > 0 and not viz[j] and retea[i][j] - flux[i][j] > 0:
                q.put(j)
                viz[j] = True
                tata[j] = i
                if j == t:
                    return True
        for j in range(1, n+1):
            if retea[j][i] > 0 and not viz[j] and flux[j][i] > 0:
                q.put(j)
                viz[j] = True
                tata[j] = -i
                if j == t:
                    return True

def Edmonds_Karp(s, t):
    global flux, retea, n
    tata = [0]*(n+1)
    f_max = flux_maxim(flux)
    while BFS(s, t, flux, tata):
        vf = t
        f_curent = float('inf')
        while vf != s:
            if tata[vf] >= 0:
                f_curent = min(f_curent, retea[tata[vf]][vf] - flux[tata[vf]][vf])
                vf = tata[vf]
            else:
                f_curent = min(f_curent, flux[vf][-tata[vf]])
                vf = -tata[vf]
        f_max += f_curent
        vf = t
        while vf != s:
            if tata[vf] >= 0:
                u = tata[vf]
                flux[u][vf] += f_curent
                vf = tata[vf]
            else:
                u = -tata[vf]
                flux[vf][u] -= f_curent
                vf = -tata[vf]
    print("Fluxul maxim :", f_max)
    for i in range(1, n+1):
        for j in range(1, n+1):
            if flux[i][j] != 0:
                if i == s:
                    print('s', j, flux[i][j])
                elif j == t:
                    print(i, 't', flux[i][j])
                else:
                    print(i, j, flux[i][j])
    print("Taietura minima :", f_max)
    arce = []
    viz = [False] * (n+1)
    q = Queue(maxsize=n)
    q.put(s)
    viz[s] = True
    while not q.empty():
        i = q.get()
        for j in range(1, n+1):
            if retea[i][j] > 0 and not viz[j] and retea[i][j] - flux[i][j] > 0:
                q.put(j)
                viz[j] = True
            elif retea[i][j] > 0 and retea[i][j] - flux[i][j] == 0:
                arce.append([i, j])
    for i, j in arce:
        print(i, j)


f = open("retea.in")
n = int(f.readline().split()[0])
s, t = [int(x) for x in f.readline().split()]
m = int(f.readline().split()[0])
retea = [[0 for i in range(n+1)]for i in range(n+1)]
flux = [[0 for i in range(n+1)]for i in range(n+1)]
for linie in f:
    ls = linie.split()
    retea[int(ls[0])][int(ls[1])] = int(ls[2])
    flux[int(ls[0])][int(ls[1])] = int(ls[3])
f.close()
if verif_flux(s, t, flux, retea):
    print("DA")
else:
    print("NU")
    exit(0)
Edmonds_Karp(s, t)
