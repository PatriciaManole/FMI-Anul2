def BFS(s, t, tata):
    global n, mat
    viz = [False] * n
    q = [s]
    viz[s] = True
    while q:
        u = q.pop(0)
        for v in range(n):
            c = mat[u][v]
            if not viz[v] and c > 0:
                q.append(v)
                viz[v] = True
                tata[v] = u
                if v == t:
                    return True
    return False

def Ford_Fulkerson(s, t):
    global n, mat
    tata = [-1]*n
    f_max = 0
    while BFS(s, t, tata):
        f_curent = float('inf')
        vf = t
        while vf != s:
            f_curent = min(f_curent, mat[tata[vf]][vf])
            vf = tata[vf]
        f_max += f_curent
        vf = t
        while vf != s:
            u = tata[vf]
            mat[u][vf] -= f_curent
            mat[vf][u] += f_curent
            vf = tata[vf]
    return f_max


f = open("retea3_FF.txt")
n, m = [int(x) for x in f.readline().split()]
s, t = [int(x) for x in f.readline().split()]
mat = [[0 for i in range(n)]for i in range(n)]
for linie in f:
    ls = linie.split()
    mat[int(ls[0])][int(ls[1])] = int(ls[2])
f.close()
print("Fluxul maxim este :", Ford_Fulkerson(s, t))
